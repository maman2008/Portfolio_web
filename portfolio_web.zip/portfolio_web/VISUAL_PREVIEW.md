# 🎨 Visual Preview - Hero Section

## 📐 Layout Structure

```
┌─────────────────────────────────────────────────────────────────┐
│                         NAVIGATION BAR                          │
│  Portfolio    [Home] [About] [Skills] [Projects] [Contact Me]  │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│  ┌──────────────────────────┐    ┌──────────────────────────┐ │
│  │                          │    │                          │ │
│  │  👋 Welcome Badge        │    │    ╭─────────────╮      │ │
│  │                          │    │   ╱   ✨ Glow    ╲     │ │
│  │  Hi, I'm                 │    │  │   ┌─────────┐  │    │ │
│  │  Abdurrohman|            │    │  │   │ Profile │  │    │ │
│  │  ▓▓▓▓▓▓▓▓▓▓▓▓            │    │  │   │  Image  │  │    │ │
│  │  a                       │    │  │   │ (Hover) │  │    │ │
│  │  Full Stack Developer|   │    │  │   └─────────┘  │    │ │
│  │  ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓     │    │   ╲   Parallax   ╱     │ │
│  │                          │    │    ╰─────────────╯      │ │
│  │  Creating modern web...  │    │      🔵 Orbiting       │ │
│  │  ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓  │    │         Dots           │ │
│  │                          │    │                          │ │
│  │  [View Projects →]       │    │                          │ │
│  │  [Download CV 📥]        │    │                          │ │
│  │                          │    │                          │ │
│  └──────────────────────────┘    └──────────────────────────┘ │
│                                                                 │
│                        ↓ Scroll Down                           │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🎭 Animation Flow

### 1. Page Load Sequence
```
Time: 0s
┌─────────────────┐
│  Page Loads     │
└────────┬────────┘
         │
Time: 0.5s
┌────────▼────────┐
│  Welcome Badge  │
│  Fades In       │
└────────┬────────┘
         │
Time: 0.8s
┌────────▼────────┐
│  "Hi, I'm"      │
│  Appears        │
└────────┬────────┘
         │
Time: 1s
┌────────▼────────┐
│  Name Typing    │
│  A|b|d|u|r...   │
└────────┬────────┘
         │
Time: 2s
┌────────▼────────┐
│  Role Typing    │
│  F|u|l|l...     │
└────────┬────────┘
         │
Time: 3s
┌────────▼────────┐
│  Subtitle Types │
│  C|r|e|a|t...   │
└────────┬────────┘
         │
Time: 4s
┌────────▼────────┐
│  Buttons Appear │
│  Profile Loads  │
└─────────────────┘
```

### 2. Typing Animation Loop
```
Full Stack Developer
▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓|  ← Typing
                      ↓ Wait 2s
Full Stack Developer|  ← Complete
                      ↓ Wait 2s
Full Stack Develope|   ← Deleting
Full Stack Develop|
Full Stack Develo|
...
|                     ← Empty
                      ↓
Laravel Expert|       ← Next role
▓▓▓▓▓▓▓▓▓▓▓▓▓|
```

---

## 🖼️ Profile Image States

### Normal State
```
    ╭─────────────╮
   ╱               ╲
  │   ┌─────────┐   │
  │   │         │   │
  │   │  Image  │   │
  │   │         │   │
  │   └─────────┘   │
   ╲               ╱
    ╰─────────────╯
```

### Hover State
```
    ╭─────────────╮
   ╱  ✨ Glow ✨   ╲
  │   ┌─────────┐   │
  │   │ Scaled  │   │ ← 1.05x
  │   │ Rotated │   │ ← 2deg
  │   │ Tilted  │   │ ← 3D
  │   └─────────┘   │
   ╲   Parallax    ╱
    ╰─────────────╯
      🔵       🔵
    Orbiting   Dots
```

---

## 📱 Responsive Breakpoints

### Mobile (< 640px)
```
┌─────────────────┐
│   Navigation    │
├─────────────────┤
│                 │
│  👋 Welcome     │
│                 │
│  Hi, I'm        │
│  Name|          │
│  Role|          │
│                 │
│  Subtitle...    │
│                 │
│  [Button 1]     │
│  [Button 2]     │
│                 │
│   ╭───────╮     │
│  ╱  Image  ╲    │
│  │         │    │
│   ╲       ╱     │
│    ╰─────╯      │
│                 │
└─────────────────┘
```

### Tablet (768px - 1024px)
```
┌─────────────────────────────┐
│       Navigation            │
├─────────────────────────────┤
│                             │
│  ┌──────────┐  ┌─────────┐ │
│  │          │  │         │ │
│  │  Text    │  │  Image  │ │
│  │  Content │  │         │ │
│  │          │  │         │ │
│  └──────────┘  └─────────┘ │
│                             │
└─────────────────────────────┘
```

### Desktop (> 1024px)
```
┌───────────────────────────────────────────┐
│            Navigation                     │
├───────────────────────────────────────────┤
│                                           │
│  ┌─────────────────┐  ┌───────────────┐  │
│  │                 │  │               │  │
│  │   Text Content  │  │  Large Image  │  │
│  │   (Left Side)   │  │  (Right Side) │  │
│  │                 │  │               │  │
│  └─────────────────┘  └───────────────┘  │
│                                           │
└───────────────────────────────────────────┘
```

---

## 🎨 Color Scheme

### Gradient Flow
```
Violet → Indigo → Purple
#667eea  #764ba2  #8b5cf6

Background:
Dark Navy → Purple Tint → Dark Navy
#0f172a     #1e1b4b      #0f172a
```

### Visual Representation
```
┌─────────────────────────────┐
│ ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ │ ← Violet
│ ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ │ ← Indigo
│ ░░░░░░░░░░░░░░░░░░░░░░░░░ │ ← Purple
└─────────────────────────────┘
```

---

## ⚡ Interactive Elements

### Button States
```
Normal:
┌─────────────────┐
│ View Projects → │
└─────────────────┘

Hover:
┌─────────────────┐
│ View Projects →→│ ← Arrow moves
└─────────────────┘
   ✨ Glow effect
```

### Cursor Trail (Optional)
```
Mouse Path:
    ●
   ●
  ●
 ●
●  ← Cursor
```

---

## 🌊 Animation Waves

### Float Animation
```
Time: 0s    ●
Time: 1s     ●
Time: 2s      ●
Time: 3s     ●
Time: 4s    ●
Time: 5s   ●
Time: 6s    ●  ← Loop
```

### Shimmer Effect
```
Gradient Text:
Frame 1: ▓▓▓░░░░░░
Frame 2: ░▓▓▓░░░░░
Frame 3: ░░▓▓▓░░░░
Frame 4: ░░░▓▓▓░░░
Frame 5: ░░░░▓▓▓░░
Frame 6: ░░░░░▓▓▓░
Frame 7: ░░░░░░▓▓▓
```

---

## 🎯 Spacing System

### Vertical Spacing
```
┌─────────────────┐
│   Section 1     │ ← py-16 (mobile)
├─────────────────┤
│                 │ ← py-20 (tablet)
│   Section 2     │
│                 │ ← py-24 (desktop)
├─────────────────┤
│   Section 3     │ ← py-28 (xl)
└─────────────────┘
```

### Horizontal Spacing
```
Mobile:    |←1rem→|Content|←1rem→|
Tablet:    |←2rem→|Content|←2rem→|
Desktop:   |←3rem→|Content|←3rem→|
```

---

## 🔄 State Transitions

### Image Hover Transition
```
Before:
┌─────────┐
│  Image  │
└─────────┘

During (0.5s):
┌─────────┐
│ Scaling │ ← Transform
│ Tilting │ ← 3D effect
│ Glowing │ ← Opacity
└─────────┘

After:
  ┌─────────┐
 ╱  Image   ╲ ← Scaled 1.05x
│   Tilted   │ ← Rotated
 ╲  Glowing ╱ ← Full glow
  └─────────┘
```

---

## 📊 Performance Visualization

### Loading Timeline
```
0s    ─────────────────────────────────────
      │ HTML Parse
0.5s  ├─────────────────────────────────────
      │ CSS Load
1.0s  ├─────────────────────────────────────
      │ JS Load
1.5s  ├─────────────────────────────────────
      │ Images Load
2.0s  ├─────────────────────────────────────
      │ Animations Start
2.5s  ├─────────────────────────────────────
      │ Fully Interactive
3.0s  └─────────────────────────────────────
```

---

## 🎪 Feature Map

```
Hero Section
├── Left Side
│   ├── Welcome Badge
│   ├── Main Heading
│   │   ├── Static Text
│   │   └── Typing Animation
│   ├── Subtitle
│   │   └── Typing Effect
│   └── CTA Buttons
│       ├── Primary Button
│       └── Secondary Button
│
└── Right Side
    └── Profile Image
        ├── Base Image
        ├── Glow Effect
        ├── Hover Animations
        │   ├── 3D Tilt
        │   ├── Scale
        │   └── Rotate
        ├── Decorative Elements
        │   ├── Floating Orbs
        │   ├── Orbiting Dots
        │   └── Rotating Ring
        └── Overlay
            └── Info Text
```

---

## 🎨 Visual Effects Legend

```
▓▓▓  = Solid/Opaque
▒▒▒  = Semi-transparent
░░░  = Very transparent
───  = Border/Line
╭─╮  = Rounded corners
│ │  = Vertical lines
✨   = Glow effect
🔵   = Decorative element
→    = Direction/Movement
|    = Cursor
●    = Dot/Point
```

---

**Use this as a visual reference while customizing!** 🎨
