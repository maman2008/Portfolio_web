<div <?php echo e($attributes->class(['fi-dropdown-list p-1'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /Users/abdurrohman/Documents/my project/portfolio/portfolio_web/vendor/filament/support/resources/views/components/dropdown/list/index.blade.php ENDPATH**/ ?>